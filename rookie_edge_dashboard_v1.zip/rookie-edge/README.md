# Rookie Edge — NFL Red-Logo Rookie Card Dashboard

A free-first browser dashboard prototype for tracking red-logo NFL rookie cards.

## What's included
- ROTY score: `card price × positive American odds / 100`
- Colors: green `< $100`; yellow `$100–< $120`; orange `$120–< $150`; red `>= $150`
- Editable card price and odds
- Odds movement versus previous entered odds
- Card-price momentum versus previous entered price
- Search, sorting, color filter, add/remove players
- CSV import/export
- Saves to browser localStorage

## Important limitations
This first version is a frontend prototype. It does **not** yet fetch live odds or card prices. Demo rows are clearly labeled examples. Data is stored only in the current browser on the current device and can be lost if browser storage is cleared. The six-hour schedule is not active until a backend and provider credentials are configured.

## Run locally
Open `index.html` in a modern browser. No build tools required.

## Free static hosting
1. Create a GitHub repository, e.g. `rookie-edge`.
2. Upload `index.html` and this README.
3. In repository Settings → Pages, choose deploy from the main branch/root.
4. Open the published Pages URL.

Do not put API keys in `index.html`; browser code is public.

## Next phase: self-updating data architecture
Recommended low-cost architecture:
- Frontend: this static HTML app on GitHub Pages.
- Scheduled worker: Python job running every six hours (e.g. GitHub Actions).
- Data store: a free-tier hosted Postgres/Supabase project, or committed JSON snapshots for a very small personal prototype.
- Odds source: a provider with an available NFL OROY futures endpoint and acceptable free-tier quota.
- Card pricing source: a source that allows automated use of comparable sales for the exact parallel. Active listing prices are not the same as completed-sale prices.
- API route: worker fetches source data, normalizes it, stores snapshots, and writes a public sanitized JSON file or serves a read-only endpoint for the dashboard.
- Refresh: cron every six hours, with provider rate limits and failures handled; show source and last-updated timestamp in the UI.

## Suggested normalized fields
`player_id, player_name, team, season, award_market, american_odds, odds_source, odds_timestamp, card_set, parallel, serial_number, grade, card_price, price_type, price_source, price_timestamp`

Store a time series for each odds quote and card-price observation. Only compare identical card variants and grades. If a provider returns negative American odds, support the full conversion separately; the ROTY score defined here is intentionally for positive American odds only.
